let speed = 0;
let coins = 0;
let pets = 0;
let rebirths = 0;

const speedEl = document.getElementById('speed');
const coinsEl = document.getElementById('coins');
const petsEl = document.getElementById('pets');

function updateUI() {
  speedEl.textContent = speed;
  coinsEl.textContent = coins;
  petsEl.textContent = pets;
}

function train() {
  speed += 1 + rebirths;
  updateUI();
}

function collect() {
  coins += speed;
  updateUI();
}

function rebirth() {
  if (coins >= 100) {
    coins = 0;
    speed = 0;
    pets += 1;
    rebirths += 1;
    updateUI();
  } else {
    alert("Pas assez de coins pour rebirth !");
  }
}

updateUI();

// 3D minimal avec un cube tournant via Canvas2D
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

let angle = 0;
function draw() {
  ctx.clearRect(0,0,canvas.width,canvas.height);
  ctx.save();
  ctx.translate(canvas.width/2, canvas.height/2);
  ctx.rotate(angle);
  ctx.fillStyle = '#0f0';
  ctx.fillRect(-50,-50,100,100);
  ctx.restore();
  angle += 0.01 + speed*0.001;
  requestAnimationFrame(draw);
}
draw();
